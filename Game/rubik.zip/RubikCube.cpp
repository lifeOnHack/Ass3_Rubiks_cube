#include "RubikCube.h"
//#define EDGE_SIZE 3
#include <stdlib.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <iostream>

RubikCube::RubikCube()
{
	int ai = EDGE_SIZE * EDGE_SIZE, aj = EDGE_SIZE;
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int j = 0; j < EDGE_SIZE; j++)
		{
			for (int k = 0; k < EDGE_SIZE; k++)
			{
				miniCubes[i][j][k] = k + aj * j + ai * i;
			}
		}
	}
}
std::vector<std::vector<int>> RubikCube::getFace(char face)
{
	switch (face)
	{
	case 'U':
		return getUpFace();
		break;
	case 'D':
		return getDownFace();
		break;
	case 'F':
		return getFrontFace();
		break;
	case 'B':
		return getBackFace();
		break;
	case 'L':
		return getLeftFace();
		break;
	case 'R':
		return getRightFace();
		break;
	default:
		return std::vector<std::vector<int>>();
		break;
	}
}



void RubikCube::printData() {
	for (int i = 0; i < EDGE_SIZE;i++) {
		for (int j = 0; j < EDGE_SIZE;j++) {
			for (int k = 0; k < EDGE_SIZE;k++) {
				int loc = 9 * i + 3 * j + k;
				std::cout << "Location " << loc << " : idx of shape at loc: " << miniCubes[i][j][k] << std::endl;
			}
		}
	}
}





std::vector<std::vector<int>> RubikCube::rotateFace(std::vector<std::vector<int>> face, bool ckw)
{
	int t1;
	/*[
	* [(02),(12),(22)],
	* [(01),(11),(21)],
	* [(00),(10),(20)]
	* ]
	*/
	if (ckw)
	{
		//tips
		t1 = face[0][2];
		face[0][2] = face[0][0];
		face[0][0] = face[2][0];
		face[2][0] = face[2][2];
		face[2][2] = t1;
		//plus
		t1 = face[1][2];
		face[1][2] = face[0][1];
		face[0][1] = face[1][0];
		face[1][0] = face[2][1];
		face[2][1] = t1;
	}
	else {
		//tips
		t1 = face[2][0];
		face[2][0] = face[0][0];
		face[0][0] = face[0][2];
		face[0][2] = face[2][2];
		face[2][0] = t1;
		//plus
		t1 = face[1][0];
		face[1][0] = face[0][1];
		face[0][1] = face[1][2];
		face[1][2] = face[2][1];
		face[2][1] = t1;
	}
	return face;
}







std::vector<std::vector<int>> RubikCube::getUpFace()
{
	std::cout << "Cubes orientation before rotating Up-Face:" << std::endl;
	printData();

	std::vector<std::vector<int>> up = std::vector<std::vector<int>> //holds the indices in the shape vector in game - that are on the face!
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int j = 2;
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			up[i][k] = miniCubes[i][j][k];
		}
	}



	/*
	
		for (int i = 0; i < EDGE_SIZE; i++) {
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			std::vector<int> locOnFaceAfterRotation= findRotatedLocation(i, k, M_PI/2);
		
			int rotated_i = locOnFaceAfterRotation[0];
			int rotated_k = locOnFaceAfterRotation[1];
			std::cout << "rotated location for: i=" << i << " k=" << k << " is: i_r=" << rotated_i << " k_r=" << rotated_k << std::endl;

			miniCubes[rotated_i][j][rotated_k] = up[i][k];
			
		}
	}

	*/


	return up;
}

std::vector<std::vector<int>> RubikCube::getDownFace() 
{
	std::vector<std::vector<int>> down = std::vector<std::vector<int>>
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int j = 0;
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			down[i][k] = miniCubes[i][j][k];
		}
	}

	/*
	
	
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			std::vector<int> locOnFaceAfterRotation = findRotatedLocation(i, k, M_PI /2);
			int rotated_i = locOnFaceAfterRotation[0];
			int rotated_k = locOnFaceAfterRotation[1];
			miniCubes[rotated_i][j][rotated_k] = down[i][k];
		}
	}
	*/

	

	return down;
}

std::vector<std::vector<int>> RubikCube::getFrontFace() 
{
	std::vector<std::vector<int>> front = std::vector<std::vector<int>>
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int k = 0;
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int j = 0; j < EDGE_SIZE; j++)
		{
			front[i][j] = miniCubes[i][j][k];
		}
	}

	/*
	
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int j = 0; j < EDGE_SIZE; j++)
		{
			std::vector<int> rotatedCoords = findRotatedLocation(i, j, M_PI /2); //changed order from i,j to j,i
			int rotated_i = rotatedCoords[0];
			int rotated_j = rotatedCoords[1];
			miniCubes[rotated_i][rotated_j][k] = front[i][j];
		}
	}
	*/


	return front;
}



std::vector<std::vector<int>> RubikCube::getBackFace() 
{
	std::vector<std::vector<int>> back = std::vector<std::vector<int>>
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int k = 2;
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int j = 0; j < EDGE_SIZE; j++)
		{
			back[i][j] = miniCubes[i][j][k];
		}
	}

	/*
	
	for (int i = 0; i < EDGE_SIZE; i++)
	{
		for (int j = 0; j < EDGE_SIZE; j++)
		{
			std::vector<int> rotatedCoords = findRotatedLocation(i, j, M_PI /2);
			int rotated_i = rotatedCoords[0];
			int rotated_j = rotatedCoords[1];
			miniCubes[rotated_i][rotated_j][k] = back[i][j];
		}
	}
	
	*/

	return back;
}

std::vector<std::vector<int>> RubikCube::getLeftFace() 
{
	std::vector<std::vector<int>> left = std::vector<std::vector<int>>
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int i = 0;
	for (int j = 0; j < EDGE_SIZE; j++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			left[j][k] = miniCubes[i][j][k];
		}
	}

	/*
	for (int j = 0; j < EDGE_SIZE; j++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			std::vector<int> rotatedCoords = findRotatedLocation(j, k, M_PI /2);
			int rotated_j = rotatedCoords[0];
			int rotated_k = rotatedCoords[1];
			std::cout << "rotated location for: j=" << j << " k=" << k << " is: j_r=" << rotated_j << " k_r=" << rotated_k << std::endl;
			miniCubes[i][rotated_j][rotated_k] = left[j][k];
		}
	}

	
	*/

	return left;
}



std::vector<std::vector<int>> RubikCube::getRightFace() 
{
	std::vector<std::vector<int>> right = std::vector<std::vector<int>>
		(EDGE_SIZE, std::vector<int>(EDGE_SIZE));
	int i = 2;
	for (int j = 0; j < EDGE_SIZE; j++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			right[j][k] = miniCubes[i][j][k];
		}
	}


	/*
	
	for (int j = 0; j < EDGE_SIZE; j++)
	{
		for (int k = 0; k < EDGE_SIZE; k++)
		{
			std::vector<int> rotatedCoords = findRotatedLocation(j, k, M_PI /2);
			int rotated_j = rotatedCoords[0];
			int rotated_k = rotatedCoords[1];
			miniCubes[i][rotated_j][rotated_k] = right[j][k];
		}
	}
	
	*/

	return right;
}



/*

std::vector<int> RubikCube::findRotatedLocation(int u, int v, float angle) { //first translate by -1 in the two axes, then rotate - then translate back to our original coords system
	angle = M_PI_2; //pi/2
	int xTranslate = -1;
	int yTranslate = -1;
	double sin_angle = sin(angle);
	double cos_angle = cos(angle);
	sin_angle = 1;
	cos_angle = 0;
	u = u + xTranslate;
	v = v + xTranslate;

	//int new_u = (u * cos_angle - sin_angle * v) - xTranslate;
	//int new_v = (u * sin_angle - v * cos_angle) - yTranslate;
	int new_u = -v - xTranslate;
	int new_v = u - yTranslate;

	std::vector<int> newCoords;
	newCoords.push_back(new_u);
	newCoords.push_back(new_v);
	return newCoords;

}

*/

