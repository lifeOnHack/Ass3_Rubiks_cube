#pragma once
#define EDGE_SIZE 3
#include <vector>
class RubikCube
{
public:
	RubikCube();
	std::vector<std::vector<int>> getFace(char face);//get face tag: 'U','L','R','B','F','D'
	//std::vector<std::vector<int>> rotateFace(std::vector<std::vector<int>> face, bool ckw);// ckw = clock-wise

	void printData();


private:
	int miniCubes[EDGE_SIZE][EDGE_SIZE][EDGE_SIZE];
	std::vector<std::vector<int>> getUpFace();
	//void setUpFace(const std::vector<std::vector<int>>& up);
	std::vector<std::vector<int>> getDownFace();
	//void setDownFace(const std::vector<std::vector<int>>& down);
	std::vector<std::vector<int>> getFrontFace();
	//void setFrontFace(const std::vector<std::vector<int>>& front);
	std::vector<std::vector<int>> getBackFace();
	//void setBackFace(const std::vector<std::vector<int>>& back);
	std::vector<std::vector<int>> getLeftFace();
	//void setLeftFace(const std::vector<std::vector<int>>& left);
	std::vector<std::vector<int>> getRightFace();
	//void setRightFace(const std::vector<std::vector<int>>& right);

	std::vector<int> findRotatedLocation(int u, int v, float angle); //find rotated location of vector: (u,v) after rotation of angle degrees about the u,v plane
	//the rotation is counter-clockwise so negative angle corresponds to clockwise-rotation


};


